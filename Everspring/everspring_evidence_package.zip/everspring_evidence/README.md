# Everspring Inn Evidence Index

This directory assembles the files cited in the Everspring Inn case study.  Each file is evidence used to document illegal evictions, regulatory failures, unpaid life‑safety fees, data manipulation, and other facts in the narrative.  Use this index to see at a glance what each item contains and why it matters.

## Quick index

| File name | Key evidence (keywords only) | Case study section |
| --- | --- | --- |
| **SDCI116_ComplaintReportOfFindings_20200901_220329.pdf** | tenant complaint, documented residency, mold, no hot water, armed guards, closed same day | Tenant complaints & evictions |
| **JSDCI116_ComplaintReportOfFindings_20200916_162554 (1).pdf** | complaint of lockout, door boarded, marked voluntary compliance | Tenant complaints & evictions |
| **SDCI116_ComplaintReportOfFindings-12-23-2024_04_35_AM.png** | portal screenshot of complaint closure, administrative closure | Tenant complaints & evictions |
| **Record-Number-007945-20CP-Seattle-Services-Portal-03-29-2025_02_56_AM.png** | portal record for complaint 007945‑20CP, closure entry | Tenant complaints & evictions |
| **Record-Number-007945-20CP-Seattle-Services-Portal-03-29-2025_03-15_AM.png** | duplicate portal record, demonstrates same‑day closure | Tenant complaints & evictions |
| **Record-Number-007948-20CP-Seattle-Services-Portal-04-02-2025_09-34_PM.png** | another complaint record showing voluntary compliance | Tenant complaints & evictions |
| **Everspring Housing code violations Adin Closed same day no contact.png** | early housing‑code complaint (Jul 29 2020) about missing fire exits and illegal units; closed immediately | Housing & safety |
| **Record Tamlpering sheoby al everspringEverspring Housing code violations AdMiNClosed 3 years later.png** | evidence of record re‑numbering or back‑dating (2020 intake labeled 2023) | Data integrity |
| **NOV Everspring Final.pdf** | official Notice of Violation citing 148 hazards (blocked egress, exposed wiring, plumbing, etc.) | Housing & safety |
| **Everspring Housing code violations AdiNClosed 3 years later.png** | late closure of a housing‑code complaint, showing years‑late administrative action | Housing & safety |
| **CONST PERMIT DUE Everspring Housing code violations AdiNClosed 3 years later.png** | unpaid construction permit fee; ties to unaddressed permit violations | Fees & permits |
| **Everspring no rrio.png** | screenshot showing no Rental Registration & Inspection Ordinance (RRIO) record for the property | Regulatory compliance |
| **elevator invoices 2018-2023.pdf** | billing history for elevator/fire certificates, shows unpaid balances | Fees & permits |
| **Boiler invoice from 23 do it 2025..pdf** | boiler maintenance bill, demonstrates active building operations despite violations | Fees & permits |
| **Record-Number-EQP-CY-04902-Seattle-Services-Portal-09-04-2025_06-30_AM.png** | elevator/fire inspection record with certification numbers | Fees & permits |
| **Record-Number-EQP-CY-04902-Seattle-Services-Portal-09-04-2025_06-40_AM.png** | another inspection record (chronological certificate numbers) | Fees & permits |
| **Record-Number-EQP-CY-04902-Seattle-Services-Portal-09-04-2025_06-45_AM.png** | inspection record, shows serial numbers in order | Fees & permits |
| **Record-Number-EQP-CY-04902-Seattle-Services-Portal-09-04-2025_12-13_PM.png** | inspection history showing multiple “passed” entries and conditions | Fees & permits |
| **RCONVEY CURRENTecord-Number-EQP-CY-04902-Seattle-Services-Portal-09-04-2025_12-21_PM.png** | result comments from 2024 inspection, listing required elevator corrections | Fees & permits |
| **Letter dated in the system for 2033 in regards to correction response on the conveyance. about water in the pit.pdf** | letter with system date 2033; proof of data‑entry error/manipulation and elevator pit water safety issue | Data integrity & safety |
| **VACANT BUILDING MON FEES DUERecord-Number-1051612-VB-Seattle-Services-Portal-09-29-2025_11-43_AM.png** | unpaid vacant‑building monitoring invoices (2021) | Fees & permits |
| **RecordList20250929.csv** | CSV listing complaints, permits and records – master record list | Master records |
| **THE-EVERSPRING-INN-EVICTIONS-REGULATORY-FAILURE-and-TENANT-ABANDONMENT.pdf** | full case study draft summarizing regulatory failures | Narrative drafts |
| **CASE STUDY EVERSPRING.pdf** | another case study draft | Narrative drafts |
| **Case Study_ Everspring Inn—A Pandemic Betrayal Background.docx** | earlier narrative background document | Narrative drafts |
| **0818 all tenants illegally evicted due to SDCI unable to respond during the middle of the pandemic..png** | annotated image summarizing mid‑August 2020 mass eviction and SDCI non‑response | Supplemental |
| **Evidence Ryan King trying to bully tenants out. submitted to the portal with a complaint..png** | photo evidence of landlord intimidation submitted with a complaint | Supplemental |
| **-Seattle-Services-Portal-Seattle-gov-31-03-2025_11_41_AM.png** | portal screenshot capturing service‑portal view used in report | Supplemental |
| **000036L7_4-pdf-09-04-2025_06_05_AM.png** | additional portal screenshot of inspection or complaint | Supplemental |
| **download.png** | spare screenshot (included for completeness) | Supplemental |

## Usage

These files can be opened directly to review the evidence backing each section of the Everspring Inn report.  The PDF and DOCX files contain narrative content or formal reports; the PNG images are mostly portal screenshots highlighting complaint statuses, inspection histories, and outstanding fees; the CSV lists the raw record numbers and intake dates used to reconstruct timelines.  Use this README as a guide to link each file to the point it supports in the report.
